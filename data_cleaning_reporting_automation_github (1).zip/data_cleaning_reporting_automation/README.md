# Data Cleaning & Reporting Automation

A beginner-friendly BTech CSE project that cleans messy sales data and automatically generates a summary report and charts using Python, Pandas, and Matplotlib.

## Project objectives
- Detect and handle missing values.
- Remove duplicate records.
- Standardize text fields and dates.
- Convert sales and quantity columns to numeric values.
- Flag invalid records and save a cleaned dataset.
- Generate summary KPIs, a text report, and visual charts.

## Tech stack
- Python 3.10+
- Pandas
- Matplotlib

## Folder structure
```text
data-cleaning-reporting-automation/
├── data/
│   └── raw_sales_data.csv
├── reports/
│   └── (generated output files appear here)
├── src/
│   └── main.py
├── tests/
│   └── test_cleaning.py
├── requirements.txt
├── .gitignore
└── README.md
```

## How to run
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the pipeline:
   ```bash
   python src/main.py
   ```

The program reads `data/raw_sales_data.csv` and creates:
- `reports/cleaned_sales_data.csv`
- `reports/data_quality_summary.csv`
- `reports/sales_summary.txt`
- `reports/monthly_revenue.png`
- `reports/top_products.png`

## Data cleaning rules
- Removes exact duplicate rows.
- Trims extra spaces and standardizes customer/product/category text.
- Parses dates using a consistent date format.
- Converts quantity and unit price to numeric values.
- Fills missing product/category values with `Unknown`.
- Fills missing customer names with `Unknown Customer`.
- Removes rows with missing/unparseable order dates, non-positive quantities, or negative prices.
- Calculates `Revenue = Quantity × UnitPrice`.

These are example business rules for this sample dataset. In a real business, rules should be confirmed with stakeholders before removing records or filling missing values.

## Example questions answered
- What is total revenue?
- Which products generate the most revenue?
- How does revenue change month by month?
- How many duplicate or invalid records were detected?

## Testing
Run:
```bash
python -m unittest discover -s tests -v
```

## Limitations and future improvements
- The input schema is designed for this sample sales dataset.
- Missing values are handled with simple rules suitable for a learning project.
- Future versions could add Excel input/output, a Power BI dashboard, logging, configurable rules, and scheduled execution.

## Author
**Your Name**  
BTech Computer Science and Engineering Student

## License
This project is shared for educational purposes under the MIT License.
