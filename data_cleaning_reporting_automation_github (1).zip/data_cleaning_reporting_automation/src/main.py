"""Clean a sample sales dataset and generate automated reports."""

from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = ROOT / "data" / "raw_sales_data.csv"
REPORT_DIR = ROOT / "reports"
REPORT_DIR.mkdir(exist_ok=True)


def clean_sales_data(df: pd.DataFrame):
    """Return (cleaned dataframe, data-quality metrics)."""
    original_rows = len(df)
    exact_duplicates = int(df.duplicated().sum())
    data = df.drop_duplicates().copy()

    required_columns = ["OrderID", "OrderDate", "Customer", "Product",
                        "Category", "Quantity", "UnitPrice"]
    missing_columns = [c for c in required_columns if c not in data.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")

    # Standardize text values and replace blank strings with missing values.
    for col in ["OrderID", "Customer", "Product", "Category"]:
        data[col] = data[col].astype("string").str.strip()
        data[col] = data[col].replace("", pd.NA)

    data["Customer"] = data["Customer"].fillna("Unknown Customer")
    data["Product"] = data["Product"].fillna("Unknown")
    data["Category"] = data["Category"].fillna("Unknown")

    # Parse dates and numeric fields safely.
    data["OrderDate"] = pd.to_datetime(data["OrderDate"], errors="coerce", dayfirst=True)
    data["Quantity"] = pd.to_numeric(data["Quantity"], errors="coerce")
    data["UnitPrice"] = (
        data["UnitPrice"].astype("string").str.replace(r"[₹,$ ]", "", regex=True)
    )
    data["UnitPrice"] = pd.to_numeric(data["UnitPrice"], errors="coerce")

    missing_or_invalid_dates = int(data["OrderDate"].isna().sum())
    invalid_quantity = int(data["Quantity"].isna().sum() + (data["Quantity"] <= 0).sum())
    invalid_price = int(data["UnitPrice"].isna().sum() + (data["UnitPrice"] < 0).sum())

    before_validation = len(data)
    data = data.dropna(subset=["OrderDate", "Quantity", "UnitPrice"])
    data = data[(data["Quantity"] > 0) & (data["UnitPrice"] >= 0)].copy()
    removed_invalid_rows = before_validation - len(data)

    data["Quantity"] = data["Quantity"].astype(int)
    data["Revenue"] = (data["Quantity"] * data["UnitPrice"]).round(2)
    data["OrderDate"] = data["OrderDate"].dt.strftime("%Y-%m-%d")
    data = data.sort_values(["OrderDate", "OrderID"], na_position="last").reset_index(drop=True)

    quality = {
        "original_rows": original_rows,
        "exact_duplicate_rows_removed": exact_duplicates,
        "rows_removed_for_invalid_date_quantity_or_price": removed_invalid_rows,
        "invalid_dates_detected": missing_or_invalid_dates,
        "invalid_quantity_values_detected": invalid_quantity,
        "invalid_price_values_detected": invalid_price,
        "final_clean_rows": len(data),
        "rows_removed_total": original_rows - len(data),
    }
    return data, quality


def generate_reports(cleaned: pd.DataFrame, quality: dict):
    """Save cleaned data, quality metrics, KPI report and charts."""
    cleaned.to_csv(REPORT_DIR / "cleaned_sales_data.csv", index=False)
    pd.DataFrame([{"metric": k, "value": v} for k, v in quality.items()]).to_csv(
        REPORT_DIR / "data_quality_summary.csv", index=False
    )

    if cleaned.empty:
        report_text = "No valid rows remained after cleaning. Please inspect the input data.\n"
        (REPORT_DIR / "sales_summary.txt").write_text(report_text, encoding="utf-8")
        return

    total_revenue = float(cleaned["Revenue"].sum())
    total_orders = int(cleaned["OrderID"].nunique())
    total_units = int(cleaned["Quantity"].sum())
    average_order_value = total_revenue / total_orders if total_orders else 0

    monthly = cleaned.copy()
    monthly["Month"] = pd.to_datetime(monthly["OrderDate"]).dt.to_period("M").astype(str)
    monthly_revenue = monthly.groupby("Month", as_index=False)["Revenue"].sum()
    top_products = (
        cleaned.groupby("Product", as_index=False)["Revenue"].sum()
        .sort_values("Revenue", ascending=False).head(10)
    )

    report_text = f"""SALES DATA CLEANING & REPORTING SUMMARY
========================================
Total valid rows: {len(cleaned)}
Unique orders: {total_orders}
Units sold: {total_units}
Total revenue: ₹{total_revenue:,.2f}
Average revenue per order: ₹{average_order_value:,.2f}

DATA QUALITY
------------
Original rows: {quality['original_rows']}
Exact duplicates removed: {quality['exact_duplicate_rows_removed']}
Rows removed for invalid date/quantity/price: {quality['rows_removed_for_invalid_date_quantity_or_price']}
Final clean rows: {quality['final_clean_rows']}

TOP PRODUCTS BY REVENUE
-----------------------
"""
    for _, row in top_products.head(5).iterrows():
        report_text += f"{row['Product']}: ₹{row['Revenue']:,.2f}\n"
    (REPORT_DIR / "sales_summary.txt").write_text(report_text, encoding="utf-8")

    plt.figure(figsize=(9, 5))
    plt.plot(monthly_revenue["Month"], monthly_revenue["Revenue"], marker="o")
    plt.title("Monthly Revenue")
    plt.xlabel("Month")
    plt.ylabel("Revenue (₹)")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    plt.savefig(REPORT_DIR / "monthly_revenue.png", dpi=150)
    plt.close()

    plt.figure(figsize=(9, 5))
    plot_data = top_products.sort_values("Revenue", ascending=True)
    plt.barh(plot_data["Product"], plot_data["Revenue"])
    plt.title("Top Products by Revenue")
    plt.xlabel("Revenue (₹)")
    plt.ylabel("Product")
    plt.tight_layout()
    plt.savefig(REPORT_DIR / "top_products.png", dpi=150)
    plt.close()


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Input file not found: {INPUT_FILE}")
    raw = pd.read_csv(INPUT_FILE)
    cleaned, quality = clean_sales_data(raw)
    generate_reports(cleaned, quality)
    print("Data cleaning and reporting completed.")
    print(f"Input rows: {quality['original_rows']}")
    print(f"Clean rows: {quality['final_clean_rows']}")
    print(f"Reports saved to: {REPORT_DIR}")


if __name__ == "__main__":
    main()
