import sys
import unittest
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from main import clean_sales_data


class TestSalesCleaning(unittest.TestCase):
    def test_removes_duplicates_and_calculates_revenue(self):
        df = pd.DataFrame([
            {"OrderID": "A1", "OrderDate": "01/01/2026", "Customer": " Maya ",
             "Product": " Pen ", "Category": " Stationery ", "Quantity": "2", "UnitPrice": "10"},
            {"OrderID": "A1", "OrderDate": "01/01/2026", "Customer": " Maya ",
             "Product": " Pen ", "Category": " Stationery ", "Quantity": "2", "UnitPrice": "10"},
        ])
        cleaned, quality = clean_sales_data(df)
        self.assertEqual(len(cleaned), 1)
        self.assertEqual(cleaned.iloc[0]["Revenue"], 20)
        self.assertEqual(cleaned.iloc[0]["Customer"], "Maya")
        self.assertEqual(quality["exact_duplicate_rows_removed"], 1)

    def test_removes_invalid_quantity(self):
        df = pd.DataFrame([
            {"OrderID": "A1", "OrderDate": "01/01/2026", "Customer": "Maya",
             "Product": "Pen", "Category": "Stationery", "Quantity": "-2", "UnitPrice": "10"},
        ])
        cleaned, quality = clean_sales_data(df)
        self.assertEqual(len(cleaned), 0)
        self.assertEqual(quality["final_clean_rows"], 0)


if __name__ == "__main__":
    unittest.main()
